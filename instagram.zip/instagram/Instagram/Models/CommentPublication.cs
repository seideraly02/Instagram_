using System.Collections.Generic;

namespace Instagram.Models
{
    public class CommentPublication
    {
        public int Id { get; set; }
        public int PublicationId { get; set; }
        public string CommentText { get; set; }
        public string UserId { get; set; }
        public User User { get; set; }
    }
}