using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Microsoft.EntityFrameworkCore.Migrations;

namespace Instagram.Models
{
    public class Publication
    {
        public int Id { get; set; }
        public string Description { get; set; }
        public DateTime CreateDateTime { get; set; } = DateTime.Now;
        public string ContentPath { get; set; }
        public string UserId { get; set; }
        public User User { get; set; }

        public int LikeCounter { get; set; }
        public int CommentCounter { get; set; }
        [NotMapped]
        public List<CommentPublication> Comment { get; set; }
        
        [NotMapped]
        [Required(ErrorMessage = "Поля обязательно для заполнения")]
        public IFormFile FormFile { get; set; }
        
    }
}