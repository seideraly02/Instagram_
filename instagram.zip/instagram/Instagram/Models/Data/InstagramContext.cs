using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace Instagram.Models.Data
{
    public class InstagramContext : IdentityDbContext<User>
    {
        public DbSet<User> Users { get; set; }
        public DbSet<Publication> Publications { get; set; }
        public DbSet<Subscription> Subscriptions { get; set; }
        public DbSet<LikePublication> Likes { get; set; }
        public DbSet<CommentPublication> Comments { get; set; }

        public InstagramContext(DbContextOptions options) : base(options){}
    }
}