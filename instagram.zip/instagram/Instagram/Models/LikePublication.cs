using System.Collections.Generic;

namespace Instagram.Models
{
    public class LikePublication
    {
        public int Id { get; set; }
        public int PublicationId { get; set; }
        public string UserId { get; set; }
        public List<User> Users { get; set; }
    }
}