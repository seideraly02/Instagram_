using Microsoft.AspNetCore.Identity;

namespace Instagram.Models
{
    public enum Gender
    {
        Man,
        Woman
    }
    
    public class User : IdentityUser
    {
        public string Login { get; set; }
        public string AvatarPath { get; set; }
        public int NumberPublications { get; set; }
        public int NumberSubscriptions { get; set; }
        public int NumberSubscribers { get; set; }
        public string UserInformation { get; set; }
        public Gender? Gender { get; set; }

    }
}