using System.ComponentModel.DataAnnotations;

namespace Instagram.ViewModel
{
    public class LoginViewModel
    {
        [Required(ErrorMessage = "Поля обязательно для заполнения")]
        public string EmailOrLogin { get; set; }
        
        [Required(ErrorMessage = "Поля обязательно для заполнения")]
        [DataType(DataType.Password)]
        public string Password { get; set; }
        public bool RememberMe { get; set; }
    }
}