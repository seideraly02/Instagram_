using System.ComponentModel.DataAnnotations;
using Instagram.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;

namespace Instagram.ViewModel
{
    public class RegisterViewModel : User
    {
        [Required(ErrorMessage = "Поля обязательно для заполнения")]
        [Remote("CheckRegisterLogin","Validation",ErrorMessage = "Пользователь с таким логином уже существует")]
        public string Login { get; set; }
        
        
        [Required(ErrorMessage = "Поля обязательно для заполнения")]
        [DataType(DataType.EmailAddress)]
        [Remote("CheckRegisterEmail","Validation",ErrorMessage = "Пользователь с таким Email уже существует")]
        public string Email { get; set; }
        
        [Required(ErrorMessage = "Поля обязательно для заполнения")]
        [DataType(DataType.Password)]
        public string Password { get; set; }
        
        [Required(ErrorMessage = "Поля обязательно для заполнения")]
        [DataType(DataType.Password)]
        [Compare("Password",ErrorMessage = "пароли не совпадают")]
        public string ConfirmPassword { get; set; }

        public string userName { get; set; }
      
        [Required(ErrorMessage = "Поля обязательно для заполнения")]
        public IFormFile FormFile { get; set; }
        public string AvatarPath { get; set; }
        
    }
}