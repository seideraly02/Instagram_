using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Instagram.Models;
using Instagram.Models.Data;
using Instagram.ViewModel;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Instagram.Controllers
{
    public class MainController : Controller
    {
        private UserManager<User> _userManager;
        private InstagramContext _db;

        public MainController(UserManager<User> userManager, InstagramContext db)
        {
            _userManager = userManager;
            _db = db;
        }

        // GET
        [Authorize]
        public IActionResult Index()
        {
            if (User.Identity.IsAuthenticated)
            {
                string userId = _userManager.GetUserId(User);
                List<Subscription> subscriptions = _db.Subscriptions
                    .Where(u => u.SubscriberUserId == userId)
                    .ToList();
                
                    List<Publication> allContents = new List<Publication>();
                
                    foreach (var userSubscription in subscriptions)
                    {
                        List<Publication> contents = _db.Publications
                            .Include(p=>p.User)
                            .Where(p => p.UserId == userSubscription.UserId)
                            .ToList();
                        foreach (var content in contents)
                        {
                            content.Comment = _db.Comments
                                .Include(c=>c.User)
                                .Where(c => c.PublicationId == content.Id).ToList();
                            allContents.Add(content);
                        }
                    }
                
                    var orderByDescending = allContents.OrderByDescending(p => p.CreateDateTime);
                    return View(orderByDescending);
            }
            return RedirectToAction("Login", "Account");
        }
    }
}