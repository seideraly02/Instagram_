#nullable enable
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Instagram.Models;
using Instagram.Models.Data;
using Instagram.ViewModel;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Hosting;

namespace Instagram.Controllers
{
    public class UsersController : Controller
    {
        private UserManager<User> _userManager;
        private IHostEnvironment _environment;
        private InstagramContext _db;
        private CreateFile _createFile;

        public UsersController(UserManager<User> userManager, IHostEnvironment environment, InstagramContext db, CreateFile file)
        {
            _userManager = userManager;
            _environment = environment;
            _db = db;
            _createFile = file;
        }

        // GET
        [Authorize]
        public IActionResult Index()
        {

            string userid = _userManager.GetUserAsync(User).Result.Id;
            List<Publication> content = _db.Publications.Where(p => p.UserId == userid)
                .OrderByDescending(p=> p.CreateDateTime)
                .ToList();
            ViewBag.Content = content;
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> AddPost(Publication publication)
        {
            if (ModelState.IsValid)
            {
                string fileName = publication.FormFile.FileName;
                string filePath = Path.Combine(_environment.ContentRootPath, "wwwroot/content/");
                _createFile.FileCreate(fileName,filePath,publication.FormFile);
                filePath = $"content/{fileName}";
                User user = await _db.Users.FirstOrDefaultAsync(u => u.Id == _userManager.GetUserId(User));
                publication = new Publication
                {
                    ContentPath = filePath,
                    UserId = _userManager.GetUserAsync(User).Result.Id,
                    Description = publication.Description
                        
                };
                user.NumberPublications += 1;
                await _db.Publications.AddAsync(publication);
                _db.Users.Update(user);
                await _db.SaveChangesAsync();

                return RedirectToAction("Index");
            }
            return NotFound();
        }
        
    }
}