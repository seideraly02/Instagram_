using System;
using System.Linq;
using System.Security.Policy;
using System.Threading.Tasks;
using Instagram.Models;
using Instagram.Models.Data;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Instagram.Controllers
{
    public class PublicationsController : Controller
    {
        private InstagramContext _db;
        private UserManager<User> _userManager;

        public PublicationsController(InstagramContext db, UserManager<User> userManager)
        {
            _db = db;
            _userManager = userManager;
        }


        // GET
        public async Task<IActionResult> AddLike(int publicationId,  string url)
        {
            
            Publication publication = await _db.Publications
                .FirstOrDefaultAsync(p => p.Id == publicationId);
            if (publication != null)
            {
                string userId = _userManager.GetUserId(User);
                LikePublication like = new LikePublication
                {
                    PublicationId = publicationId,
                    UserId = userId
                };
                LikePublication result = _db.Likes.FirstOrDefault(l =>
                    l.PublicationId == like.PublicationId && l.UserId == like.UserId);
                if (result != null)
                {
                    publication.LikeCounter -= 1;
                    _db.Entry(result).State = EntityState.Deleted;
                }
                else
                {
                    publication.LikeCounter += 1;
                    await _db.Likes.AddAsync(like);
                    
                }
                _db.Publications.Update(publication);
                await _db.SaveChangesAsync();
                return Json(publication.LikeCounter);

            }
           
            return NotFound();
        }

        [HttpPost]
        public async Task<IActionResult> AddComment(int publicationId,string comment)
        {
            Publication publication = _db.Publications.FirstOrDefault(p => p.Id == publicationId);
            if (publication != null)
            {
                CommentPublication commentPublication = new CommentPublication
                {
                    PublicationId = publicationId,
                    CommentText = comment,
                    UserId = _userManager.GetUserId(User)
                };
                
                publication.CommentCounter += 1;
                _db.Publications.Update(publication);

                await _db.Comments.AddAsync(commentPublication);
                await _db.SaveChangesAsync();
            }
            
            return RedirectToAction("Index", "Main");
          
        }

        public IActionResult Edit(int publicationId, string descriptionText)
        {
            Console.WriteLine(publicationId + descriptionText);
            Publication publication = _db.Publications.FirstOrDefault(p => p.Id == publicationId);
            if (publication != null)
            {
                publication.Description = descriptionText;
                _db.Publications.Update(publication);
                _db.SaveChangesAsync();
                return Json(true);
            }
            return NotFound();
        }
    }
}