using System.IO;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using Instagram.Models;
using Instagram.Models.Data;
using Instagram.ViewModel;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Internal;
using Microsoft.Extensions.Hosting;

namespace Instagram.Controllers
{
    public class AccountController : Controller
    {
        private UserManager<User> _userManager;
        private SignInManager<User> _signInManager;
        private InstagramContext _db;
        private CreateFile _createFile;
        private IHostEnvironment _environment;

        public AccountController(UserManager<User> userManager, SignInManager<User> signInManager, InstagramContext db, CreateFile file, IHostEnvironment environment)
        {
            _userManager = userManager;
            _signInManager = signInManager;
            _db = db;
            _createFile = file;
            _environment = environment;
        }


        // GET
        
        public  IActionResult Login()
        {
            return View();
        }
        [HttpPost]
        public  async Task<IActionResult> Login(LoginViewModel model)
        {
            if (ModelState.IsValid)
            {
                
                var user = await _userManager.FindByEmailAsync(model.EmailOrLogin) 
                           ?? await _db.Users.FirstOrDefaultAsync(u => u.Login == model.EmailOrLogin);

                if (user != null)
                {
                    
                    var result = await _signInManager.PasswordSignInAsync(
                        user,
                        model.Password,
                        model.RememberMe,
                        false
                        );
                    if (result.Succeeded)
                    {
                        return RedirectToAction("Index", "Main");
                    }
                    ModelState.AddModelError("","Неверный пароль пльзавателя");
                }
                else
                {
                     ModelState.AddModelError("","Пользователь не зарегестрирован");
                }
               
            }
            return View(model);
        }


        public  IActionResult Register()
        {
            return View();
        }
        
        [HttpPost]
        public async Task<IActionResult> Register(RegisterViewModel model)
        {
            
            if (ModelState.IsValid)
            {
                string filePath = Path.Combine(_environment.ContentRootPath, "wwwroot/avatar/");
                _createFile.FileCreate(model.FormFile.FileName, filePath, model.FormFile);
                string avatarPath = $"avatar/{model.FormFile.FileName}";
                
                User user = new User
                {
                    Login = model.Login,
                    Email = model.Email,
                    AvatarPath = avatarPath,
                    UserName = model.userName ?? model.Login,
                    PhoneNumber = model.PhoneNumber,
                    Gender = model.Gender,
                    UserInformation = model.UserInformation
                };
                
                var result = await _userManager.CreateAsync(user, model.Password);
                if (result.Succeeded)
                {
                    await _signInManager.SignInAsync(user, false);
                    return RedirectToAction("Index", "Main");
                }

                foreach (var error in result.Errors)
                    ModelState.AddModelError(string.Empty,error.Description);
            }
            
            return View(model);
        }

        public async Task<IActionResult> LogOut()
        {
            await _signInManager.SignOutAsync();
            return RedirectToAction("Login", "Account");
        }
        
    }
}