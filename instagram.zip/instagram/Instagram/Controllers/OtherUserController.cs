using System.Collections.Generic;
using System.IO.Enumeration;
using System.Linq;
using System.Security.Policy;
using System.Threading.Tasks;
using Instagram.Models;
using Instagram.Models.Data;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Instagram.Controllers
{
    public class OtherUserController : Controller
    {
        private InstagramContext _db;
        private UserManager<User> _userManager;

        public OtherUserController(InstagramContext db, UserManager<User> userManager)
        {
            _db = db;
            _userManager = userManager;
        }

        // GET
        public async Task<IActionResult> Index(string userId = null)
        {
            User user = await _userManager.FindByIdAsync(userId);
            List<Publication> content = _db.Publications.Where(p => p.UserId == user.Id).ToList();
            ViewBag.Content = content;
            bool result = await CheckingSubscription(user.Id);
            ViewBag.Result = result;
            return View(user);
        }
        
        
        public IActionResult Search(string? value)
        {
            if (value != null)
            {
                List<User> users = _db.Users.Where(u => u.UserName != User.Identity.Name
                                                        && u.Login.Contains(value)
                                                        || u.UserName != User.Identity.Name
                                                        && u.UserName.Contains(value) 
                                                        || u.UserName != User.Identity.Name
                                                        && u.Email.Contains(value)
                                                        || u.UserName != User.Identity.Name
                                                        && u.UserInformation.Contains(value)).ToList();
                
                
                return View(users);
            }
            return RedirectToAction("Index","Users");
        }


        public async Task<IActionResult> Subscribe(string userId)
        {
            User user = _db.Users.FirstOrDefault(u => u.Id == userId);
            if (user != null)
            {
                bool checkingSubscription = await CheckingSubscription(userId);
                User userSubscriber = await _userManager.FindByNameAsync(User.Identity.Name);
                Subscription subscription = new Subscription
                {
                    UserId = user.Id,
                    SubscriberUserId = userSubscriber.Id
                };
                if (checkingSubscription == false)
                {
                    await _db.Subscriptions.AddAsync(subscription);
                    user.NumberSubscribers += 1;
                    _db.Users.Update(user);

                    userSubscriber.NumberSubscriptions += 1;
                    _db.Users.Update(userSubscriber);
                    _db.SaveChanges();

                    List<Publication> content = _db.Publications.Where(p => p.UserId == user.Id).ToList();
                    ViewBag.Content = content;

                    bool result = await CheckingSubscription(user.Id);
                    ViewBag.Result = result;
                    return View(nameof(Index), user);

                }

                Subscription subscriptionRemove = _db.Subscriptions.FirstOrDefault(s =>
                        s.SubscriberUserId == subscription.SubscriberUserId && s.UserId == subscription.UserId);
                    if (subscriptionRemove != null)
                    {
                        _db.Subscriptions.Remove(subscriptionRemove);
                        user.NumberSubscribers -= 1;
                        _db.Users.Update(user);

                        userSubscriber.NumberSubscriptions -= 1;
                        _db.Users.Update(userSubscriber);
                        _db.SaveChanges();
                        return Json(true);
                    }
            }

            return NotFound();
        }

        public async Task<bool> CheckingSubscription(string userId)
        {
            User identity = await _userManager.FindByNameAsync(User.Identity.Name);
            return  _db.Subscriptions.Any(u => u.UserId == userId && u.SubscriberUserId == identity.Id);
        }
        public IActionResult Details(int publicationId)
        {
            
            Publication publication = _db.Publications.Include(u=> u.User).FirstOrDefault(p => p.Id == publicationId);
            if (publication != null)
            {
                publication.Comment = _db.Comments.Include(p=>p.User).Where(p => p.PublicationId == publicationId).ToList();
                return View(publication);
            }
            return NotFound();
        }

        public async Task<IActionResult> Remove(int publicationId)
        {
            Publication publication = await _db.Publications.FirstOrDefaultAsync(p => p.Id == publicationId);
            if (publication != null)
            {
                _db.Remove(publication);
                await _db.SaveChangesAsync();
                return Json("true");
            }
            return NotFound();
        }

        public IActionResult GetSubscriptionData(string userId )
        {
            User user =  _db.Users.FirstOrDefault(u => u.Id == userId);
            if (user != null)
            {
                return Json(user.NumberSubscribers);
            }

            return NotFound();
        }
    }
}