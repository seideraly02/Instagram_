using System.Linq;
using Instagram.Models;
using Instagram.Models.Data;
using Microsoft.AspNetCore.Identity;

namespace Instagram.Controllers
{
    public class ValidationController
    {
        private InstagramContext _db;

        public ValidationController(InstagramContext db)
        {
            _db = db;
        }

        public bool CheckRegisterLogin(string login)
        {
            return !_db.Users.Any(u => u.Login == login);
        }
        public bool CheckRegisterEmail(string email)
        {
            return !_db.Users.Any(u => u.Email == email);
        }
    }
}